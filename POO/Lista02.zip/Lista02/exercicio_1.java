package Exercicio01;

import java.util.Scanner;

public class exercicio_1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		float vetor[]= new float[10];
		int i = 0;
		int resp;
		while(i<10) {
			System.out.println("Digite o "+(i+1)+" numero do vetor:");
			vetor[i] = scan.nextFloat();
			i++;
		}
		
		imprimevalores(vetor,9);
		System.out.println("\nQuer saber qual maior valor, menor valor e meia dos numero do vetor?(0)Nao(1)Sim");
		resp = scan.nextInt();
		if(resp==1) {
			Dados(vetor,10);
		}
	}
	
	public static void imprimevalores(float vetor[],int i) {
		System.out.println("Impressao dos vetor em ordem contr�ria: ");
		while(i>=0 ) {
			System.out.print(vetor[i]+" ");
			i--;
		}
	}
	public static void Dados(float vetor[],int j) {
		float media=vetor[0];
		float maior=vetor[0];
		float menor=vetor[0];
		for(int i=1;i<j;i++) {
			if(maior<=vetor[i]) {
				maior=vetor[i];
			}
			if(menor>=vetor[i]) {
				menor=vetor[i];
			}
			media+=vetor[i];	
		}
		System.out.println("Maior valor="+maior+" Menor valor="+menor+" Media="+media/(j));
	}

}
