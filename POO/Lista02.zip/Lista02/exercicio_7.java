package Exercicio01;

import java.util.Scanner;

public class exercicio_7 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int tabela[][]= new int[4][3];
		int salva;
		for(int i=0;i<4;i++) {
			for(int j=0;j<3;j++) {
				System.out.print("Digite o numero da posi��o "+(i+1)+" linha,"+(j+1)+" coluna: ");
				salva = scan.nextInt();
				tabela[i][j] = salva;
			}
		}
		System.out.print("O maior valor da tabela �: "+ maValor(tabela,4,3));
		
	}
	public static int maValor(int tabel[][],int linha,int coluna) {
		int valorMaior=tabel[0][0];
		for(int i=0;i<4;i++) {
			for(int j=0;j<3;j++) {
				if(valorMaior<=tabel[i][j]) {
					valorMaior=tabel[i][j];
				}
			}
		}
		return valorMaior;
		
	}

}
