package Exercicio01;

import java.util.Scanner;

public class exercicio_6 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int vetor[] = new int[10];
		for(int i=0;i<10;i++) {
			vetor[i] =  1+(int)(Math.random() *100);	
		}
		int resp;
		int ar=-1;
		System.out.print("O computador preencheu um vetor de 10 posi��es com numeros aleatorios de 1 a 100");
		resp = scan.nextInt();
		System.out.println("O vetor esta abaixo:");
		for(int i =0; i<10;i++) {
			System.out.print(vetor[i]+" ");
			if(vetor[i]==resp) {
				ar=vetor[i];
			}			
		}
		if(ar!=-1) {
			System.out.println("\nVoce acertou");
		}else{
			System.out.println("\nVoce errou");
		}
			
	}

}
