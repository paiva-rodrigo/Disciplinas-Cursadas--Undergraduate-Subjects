package Exercicio01;

public class exercicio_5 {

	public static void main(String[] args) {
		int mat1 [][] = new int[3][3];
		int mat2 [][] = new int[3][3];
		for (int i=0;i<3;i++){
			for (int j=0;j<3;j++) {
				mat1[i][j]=1;
			}
		}
		for (int i=0;i<3;i++){
			for (int j=0;j<3;j++) {
				mat2[i][j]=2;
			}
		}
		int mat4[][] = new int[3][3];
		mat4=SomaMatrizes(mat1,mat2);
		System.out.println("Matriz impressa:");
		for (int i=0;i<3;i++){
			System.out.println("");
			for (int j=0;j<3;j++) {
				System.out.print(mat4[i][j]+" ");
			}
		}
		

	}

	private static int[][] SomaMatrizes(int[][] mat1, int[][] mat2) {
		int mat3[][] = new int[3][3];
		for (int i=0;i<3;i++){
			for (int j=0;j<3;j++) {
				mat3[i][j]=mat1[i][j]+mat2[i][j];
			}
		}
		return mat3;
	}

}
