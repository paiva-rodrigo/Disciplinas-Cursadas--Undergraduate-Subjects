package Exercicio01;

import java.util.Scanner;

public class exercicio_8 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int tabela[][]= new int[3][3];
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print("Digite o numero da posi��o "+(i+1)+" linha,"+(j+1)+" coluna: ");
				tabela[i][j] = scan.nextInt();
			}
		}
		int resp;
		System.out.print("O que voce deseja fazer agora? (1)Mostrar a 1a linha da tabela (2)Mostrar a soma dos numeros acima da diagonal principal");
		resp = scan.nextInt();
		if(resp==1) {
			MostrarLinha1(tabela,3);			
		}
		else if(resp==2) {
			System.out.print("A soma acima da diagonal principal vale:"+SomaDiagonalPrincipal(tabela,3,3));			
		}
		else {
			System.out.print("Dgitou um caracter invalido");
		}
	}

	private static int SomaDiagonalPrincipal(int tabel[][],int coluna,int linha) {
		int soma=0;
		for(int i=0;i<linha;i++) {
			for(int j=0;j<coluna;j++) {
				if(j>i) {
					soma+=tabel[i][j];
				}
			}
		}
		return soma;
	}

	private static void MostrarLinha1(int tabel[][],int coluna) {
		 for(int i=0;i<coluna;i++) {
			 System.out.print(" "+tabel[0][i]);
		 }
	}

}
