package Exercicio01;

import java.util.Scanner;

public class exercicio_2 {

	public static void main(String[] args) {
		double a,b,c;
		Scanner scan = new Scanner(System.in);
		System.out.print("Digite o valor do 1o cateto: ");
		a=scan.nextDouble();
		System.out.print("\nDigite o valor do 2o cateto: ");
		b=scan.nextDouble();
		c=Baskara(a,b);
		System.out.print("\nO valor da hipotenusa e: "+c);
		
	}
	public static double Baskara(double a,double b) {
		double hipo=Math.sqrt(a*a+b*b);		
		return hipo;		
	}

}
