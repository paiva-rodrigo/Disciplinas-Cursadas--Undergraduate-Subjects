package Exercicio01;

import java.util.Scanner;
public class exercicio_3 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		int resp;
		int rod = 1 + (int)(Math.random() * 10);
		System.out.print("o computador digitou um numero de 0 a 10, tente adivinha-lo:");
		resp = scan.nextInt();
		if(rod==resp) {
			System.out.print("Voce acertou");
		}else {
			System.out.print("Voce errou o numero e "+rod);
		}
	}

}
