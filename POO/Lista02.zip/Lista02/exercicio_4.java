package Exercicio01;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class exercicio_4 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		int resp;
		int rod;
		while(true) {
			rod=Aleatorio();
			System.out.print("\nO computador digitou um numero de 0 a 10, tente adivinha-lo:(-1)Sair\n");
			resp = scan.nextInt();
			if(rod==resp) {
				System.out.print("Voce acertou");
			}
			else if(resp==-1) {
				break;
			}
			else {	
				System.out.print("Voce errou o numero � "+rod);				
			}			
		}
		
	}

	private static int Aleatorio() {
		return 1 + (int)(Math.random() * 10);
		}
}
