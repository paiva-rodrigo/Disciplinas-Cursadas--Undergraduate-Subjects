import java.util.Scanner;

public class exercio_5 {

	public static void main(String[] args) {
		int a;
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite um numero: ");
		a = entrada.nextInt();
		System.out.println("O somatorio de "+a+":");
		int somatorio=0;
		for(int i = 1; i<(a+1);i++) {			
			if(i==a) {
				System.out.print(i+"=");
				somatorio+=i;
			}else {
				System.out.print(i+"+");
				somatorio+=i;
			}
		}
		System.out.print(somatorio);
		System.out.println("\nO somatorio de "+a+" e "+somatorio);
	}

}
