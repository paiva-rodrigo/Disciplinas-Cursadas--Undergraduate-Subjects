
import java.util.Scanner;

public class exercicio_3 {

	public static void main(String[] args) {
		int n1,n2;
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite um numero inteiro: ");
		n1 = entrada.nextInt();
		System.out.println("Digite outro numero inteiro: ");
		n2 = entrada.nextInt();
		if(n1>n2) {
			System.out.println("o maio numero e "+n1);
		}else if(n1<n2) {
			System.out.println("o maio numero e "+n2);
		}else {
			System.out.println("Os dois numeros sao iguais ");
		}

	}

}
