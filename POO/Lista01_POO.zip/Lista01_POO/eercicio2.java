import java.util.Scanner;

public class eercicio2 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		Double a1,a2;
		System.out.println("Digite um numero: ");
		a1=entrada.nextDouble();
		System.out.println("Digite outro numero: ");
		a2=entrada.nextDouble();
		
		System.out.println("\nsoma "+a1+" + "+a2+" = "+(a1+a2));
		System.out.println("divisao "+a1+" / "+a2+" = "+(a1/a2));
		System.out.println("subtracao "+a1+" - "+a2+" = "+(a1-a2));
		System.out.println("multiplicacao "+a1+" * "+a2+" = "+(a1*a2));

	}

}
