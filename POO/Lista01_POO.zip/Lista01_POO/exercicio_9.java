import java.util.Scanner;

public class exercicio_9 {

	public static void main(String[] args) {
	Scanner entrada = new Scanner(System.in);
	int litros,kilometros,ki;
	ki=1;
	double kmlitro;
	while(ki==1) {
		System.out.println("Deseja calcular a media de kilometros por litro? (1)sim (0)nao");		
		ki = entrada.nextInt();
		if(ki==1) {
			System.out.println("Digite quantos kilometros andados: ");		
			kilometros = entrada.nextInt();
			System.out.println("Digite quantos litros gastos: ");		
			litros = entrada.nextInt();
			System.out.println("voce fez uma media de "+(kilometros/litros)+"km/litro");
		}
		
	}

	}
}
