
import java.util.Scanner;

public class exerccio_8 {

	public static void main(String[] args) {
		Scanner entrada=new Scanner(System.in);
		int i=0;
		double salariototal = 0,salariolocal;
		boolean parada = false;
		while(parada==false) {						
			System.out.println("Digite o salario do funcionario "+(i+1)+":(Digite -1 quando acabar) ");
			salariolocal = entrada.nextDouble();
			
			if(salariolocal == -1) {
				parada=true;			
			}else {
				salariototal += salariolocal;
				i+=1;
			}
		}
		System.out.println("O salario total dos "+i+" funcinarios �: "+salariototal);
		System.out.println("A media e: "+(salariototal/i));
	}

}
