import java.lang.Math;
import java.util.Scanner;

public class exercicio_10 {

	public static void main(String[] args) {
			double a,b,c;
			Scanner entrada = new Scanner(System.in);
			System.out.println("Digite o valor de a da equacao do 2� (a*x^2+b*x*c = 0): " );
			a = entrada.nextDouble();
			System.out.println("Digite o valor de b da equacao do 2� (a*x^2+b*x*c = 0): " );
			b = entrada.nextDouble();
			System.out.println("Digite o valor de c da equacao do 2� (a*x^2+b*x*c = 0): " );
			c = entrada.nextDouble();
			double det = delta(a,b,c);
			bascara(det,b,a,c);
		}
		public static double delta(double a,double b,double c) {
			return (b*b-4*a*c);
		}
		public static void bascara(double delta,double b,double a,double c) {
			double x1 = (-b+Math.sqrt(delta))/(2*a);
			double x2 = (-b-Math.sqrt(delta))/(2*a);
			
			System.out.println("As raizes da equacao "+a+"*x^2 + "+b+"*x + "+c+" = 0 sao: x1="+x1+" x2="+x2);
		}


	}
