
import java.util.Scanner;

public class exercicio_1 {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		int idade;
		String nome;
		
		System.out.print("Qual o seu nome?");
		nome = scanner.next();
		System.out.print("Qual a sua idade?");
		idade = scanner.nextInt();
		
		System.out.println(nome + " sua idade e " + idade);
	}

}
