
import java.util.Scanner;

public class exercicio_4 {

	public static void main(String[] args) {
		int parada;
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o numero de paradad de uma sequencia: ");
		parada = entrada.nextInt();
		System.out.println("\n\nInicio da contagem:");
		for(int i = 1;i<=parada;i++) {
			System.out.print(" "+i);
		}
		
	}

}
