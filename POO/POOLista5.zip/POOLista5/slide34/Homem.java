package slide34;

public class Homem extends Animal{
	public void fala() {
		System.out.print(" Oi ");
	}
}
