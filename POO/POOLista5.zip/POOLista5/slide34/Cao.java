package slide34;

public class Cao extends Animal{
	public void fala() {
		System.out.print(" AuAu ");
	}
}
