package slide34;

public class Main {

	public static void main(String[] args) {
		Animal[] vetor = new Animal[10];

		vetor[0] = new Homem();
		vetor[1] = new Homem();
		vetor[2] = new Homem();
		vetor[3] = new Cao();
		vetor[4] = new Cao();
		vetor[5] = new Cao();
		vetor[6] = new Cao();
		vetor[7] = new Gato();
		vetor[8] = new Gato();
		vetor[9] = new Gato();
		
		for (int i =0;i<10;i++) {
			vetor[i].fala();
		}
		
	}

}
