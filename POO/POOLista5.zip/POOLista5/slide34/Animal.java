package slide34;

public class Animal {
	public void fala() {
		System.out.print("Som: ");
	}
}
