package slide34;

public class Gato extends Animal{
	public void fala() {
		System.out.print(" Miau ");
	}
}
