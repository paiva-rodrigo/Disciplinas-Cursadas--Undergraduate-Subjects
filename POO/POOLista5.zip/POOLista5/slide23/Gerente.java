package slide23;

public class Gerente extends Funcionario{
	Gerente(String nome, String senha) {
		super(nome, senha);
	}
	float total = getTotalVendido();
	public void fechamentoCaixa() {
		System.out.print("\n\nGerente: "+this.getNome());
		System.out.print("\nFECHAMENTO DO CAIXA:\nA empresa obteve R$:"+this.total+" de produtos vendidos");
	}
	
}
