package slide23;

public class Funcionario extends Usuario{
	public Funcionario(String nome,String senha){
		super(nome,senha);
	}
	private static float totalVendido = 0;
	
	public void Venda(String NomeProduto,float preco,Cliente clt1) {
		System.out.println("\n"+getNome()+" vendeu o produto "+NomeProduto+" por RS"+preco);
		System.out.println("Dados do cliente:");
		clt1.DadosGerais();
		this.totalVendido = this.totalVendido+preco;
	}
	
	public float getTotalVendido(){
		return this.totalVendido;
	}
}
