package slide23;

public class Main {
	public static void main(String[] args) {	
		Cliente clt1 = new Cliente("Rod","111",142);
		Cliente clt2 = new Cliente("Teix","222",444);
		Cliente clt3 = new Cliente("Fra","333",666);
		
		Funcionario fun1 = new Funcionario("Rodrigo1","123");		
		fun1.Venda("Batata", 10,clt1);
		Funcionario fun2 = new Funcionario("Rodrigo2","123");		
		fun2.Venda("carne", 20,clt2);
		Funcionario fun3 = new Funcionario("Rodrigo3","123");		
		fun1.Venda("sorvete", 30,clt3);
		
		
		Gerente gr1 = new Gerente("Gerente","123456");
		gr1.fechamentoCaixa();
	}

}
