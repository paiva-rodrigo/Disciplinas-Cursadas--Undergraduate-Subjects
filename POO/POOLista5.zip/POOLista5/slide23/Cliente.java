package slide23;

public class Cliente extends Usuario{
	private int cpf;
	private int a=0;
	public Cliente(String nome,String senha,int cpf){
		super(nome,senha);
		this.cpf=cpf;
	}
	
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public void DadosGerais(){
		System.out.println("Nome: "+ getNome());
		System.out.println("Senha: "+ getSenha());
		System.out.println("CPF: "+ getCpf());
	}
	
}
