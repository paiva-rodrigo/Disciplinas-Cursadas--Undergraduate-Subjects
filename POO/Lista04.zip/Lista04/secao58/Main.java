package secao5_8;

public class Main {

	public static void main(String[] args) {
		
		//Exercicio1
		/*Resposta no Arquivo de Texto*/
		
		//Exercicio2
		/*Ex_2Conta TesteConta2 = new Ex_2Conta();
		System.out.println(TesteConta2.nome);
		TesteConta2.nome = "Rodriguinho";*/
		
		
		//Exercicio3
		/*Ex_2Conta TesteConta3 = new Ex_2Conta();
		TesteConta3.setAgencia("1111");
		TesteConta3.setData(22,22,22);
		TesteConta3.setNome("Rodriguinho");
		TesteConta3.setNumero(3333);
		TesteConta3.setSaldo(4444);
		TesteConta3.recuperaDadosParaImpressao();*/
		
		//Exercicio4
		/*Ex_4Conta TesteConta4 =new Ex_4Conta("Afeganist�o");
		TesteConta4.recuperaDadosParaImpressao();
		*/
		
		
		//Exercicio5		
	    /*Ex_5Conta TesteConta51 =new Ex_5Conta("Afeganist�o");
		TesteConta51.recuperaDadosParaImpressao();
		Ex_5Conta TesteConta52 =new Ex_5Conta("Gorl�ndia");
		TesteConta52.recuperaDadosParaImpressao();*/
		
		
		//Exercicio6
		/*Ex_6Conta TesteConta61 =new Ex_6Conta("Afeganist�o");
		TesteConta61.setData(10, 20, 12);//acusa mes invalido
		*/
		
		//Exercicio7
		/*Resposta no Arquivo de Texto*/
		
		
		
		
		
		
	}

}
