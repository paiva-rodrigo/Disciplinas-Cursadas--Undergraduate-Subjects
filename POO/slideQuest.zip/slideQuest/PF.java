package slideQuest;
 
public class PF extends Cliente{
    private String cpf;

    public PF(long codigo,String cpf) {
        super(codigo);
        this.cpf = cpf;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public String todosDados(){
        return "Código:"+getCodigo() + " CPF:" + getCpf();
    }
}
