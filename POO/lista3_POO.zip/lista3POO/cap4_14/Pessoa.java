package cap4_14;

public class Pessoa {
	String nome;
	int idade;
	
	int FazerAniversario() {
		System.out.print("\nidade = "+(this.idade+1));		
		return this.idade+=1;	
	}	
}
