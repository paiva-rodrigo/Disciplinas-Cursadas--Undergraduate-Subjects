package cap4_14;

public class Porta {
	boolean aberta ;
	String cor;	
	int dimensaoX,	dimensaoY,	dimensaoZ;
	void	abre() {
		this.aberta = true;
	}
	void	fecha()	{
		this.aberta = false;
	}
	void	pinta(String	s) {
		this.cor = s;
	}
	void	estaAberta() {
		if(this.aberta) {
			System.out.println("\nEsta aberta");
		}else {
			System.out.println("\nEsta fechada");
		}		
	}

}
