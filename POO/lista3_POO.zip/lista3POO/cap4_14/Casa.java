package cap4_14;

public class Casa {
	String cor;
	Porta	porta1 = new Porta();
	Porta	porta2 = new Porta();
	Porta	porta3 = new Porta();
	void	pinta(String	s) {
		this.cor=s;
	}	
	
	int	quantasPortasEstaoAbertas() {
		int ad=0;
		if(porta1.aberta == true) {
			ad++;
		}
		if(porta2.aberta == true) {
			ad++;	
		}
		if(porta3.aberta == true) {
			ad++;
		}
		return ad;
	}
}
