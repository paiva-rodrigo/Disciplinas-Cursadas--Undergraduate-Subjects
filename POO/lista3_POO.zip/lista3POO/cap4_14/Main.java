package cap4_14;

public class Main {

	public static void main(String[] args) {
		//Programa1
		Pessoa pess = new Pessoa();
		pess.idade=10;
		pess.nome="Rodrigo";
		pess.FazerAniversario();
		pess.FazerAniversario();
		
		//Programa2
		Porta port = new Porta();
		port.aberta = true;
		port.cor = "Vermelho";
		port.dimensaoX = 10;
		port.dimensaoY = 10;
		port.dimensaoZ = 10;
		port.abre();
		port.fecha();
		port.estaAberta();
		port.cor = "Vermelho";
		port.dimensaoX = 15;
		port.dimensaoY = 15;
		port.dimensaoZ = 15;
		port.abre();
		port.estaAberta();
		
		//Programa3
		Casa casa = new Casa();
		casa.pinta("Azulllllll");
		casa.porta1.abre();
		casa.porta2.abre();
		casa.porta3.abre();
		System.out.print(casa.quantasPortasEstaoAbertas());
		casa.porta1.fecha();
		casa.porta2.abre();
		casa.porta3.abre();
		System.out.print("\n");
		System.out.println(casa.quantasPortasEstaoAbertas());
		
		

	}

}
