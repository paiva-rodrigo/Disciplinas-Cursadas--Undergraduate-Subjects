package scriptsjava;

public class Ex_9Conta {
	String nome;
	int numero;
	String agencia;
	double saldo;
	Ex_9Data data;
	
	
	String	recuperaDadosParaImpressao() {
		String dados	=	"\nData	de	abertura:	"	+	this.data.formatada();
		return	dados;
	}
	
	public void saca(double valorsacado) {
		this.saldo = this.saldo-valorsacado;
		System.out.print("\nsaldo : "+ this.saldo);
	}
	
	public void deposita(double deposito) {
		this.saldo = this.saldo+deposito;
		System.out.print("\nsaldo : "+ this.saldo);
	}
	
	public void CalcRendimento() {
		System.out.print("\nRendimento:"+this.saldo*0.1);
	}
	
}
