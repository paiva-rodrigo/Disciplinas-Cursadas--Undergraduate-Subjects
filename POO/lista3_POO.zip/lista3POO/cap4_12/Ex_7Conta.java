package scriptsjava;

public class Ex_7Conta {
	String nome;
	int numero;
	String agencia;
	double saldo;
	Ex_6Data data;
	
	public void saca(double valorsacado) {
		this.saldo = this.saldo-valorsacado;
		System.out.print("\nsaldo : "+ this.saldo);
	}
	
	public void deposita(double deposito) {
		this.saldo = this.saldo+deposito;
		System.out.print("\nsaldo : "+ this.saldo);
	}
	
	public void CalcRendimento() {
		System.out.print("\nRendimento:"+this.saldo*0.1);
	}
	
	public String recuperaDadosParaImpressao() {
		String	dados	=	"\nTitular:	"	+	this.nome;		
		dados	+=	"\nDia:	"	+	this.data.dia;
		dados	+=	"\nM�s:	"	+	this.data.mes;
		dados	+=	"\nAno:	"	+	this.data.ano;
		return	dados;
	}
}
