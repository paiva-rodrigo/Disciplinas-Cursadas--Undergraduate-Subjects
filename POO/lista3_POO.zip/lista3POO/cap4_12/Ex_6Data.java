package scriptsjava;

public class Ex_6Data {

	int dia;
	int mes;
	int ano;
	public void Dados() {
		System.out.print("\ndia:"+this.dia);
		System.out.print(" mes:"+this.mes);
		System.out.print(" ano:"+this.ano);
	}
}
