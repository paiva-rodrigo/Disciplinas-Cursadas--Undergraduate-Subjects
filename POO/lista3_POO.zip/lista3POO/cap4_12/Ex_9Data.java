package scriptsjava;

public class Ex_9Data {
	int dia;
	int mes;
	int ano;
	public void Dados() {
		System.out.print("\ndia:"+this.dia);
		System.out.print(" mes:"+this.mes);
		System.out.print(" ano:"+this.ano);
	}
	
	String formatada() {
		String res = Integer.toString(dia)+"/"+Integer.toString(mes)+"/"+Integer.toString(ano);
		
		return res;
	}
	
	
}
