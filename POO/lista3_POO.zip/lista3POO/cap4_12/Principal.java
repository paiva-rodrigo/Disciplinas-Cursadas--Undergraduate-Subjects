package scriptsjava;



/*Ao professor:
 * nessa classe principal est�o o funcionamento de cada progama comentados 
 * e separados abaixo para executar cada exercicio veja as classes que ele pede, 
 * aconselho abrir todas as classes na mesma pasta que essa classe
 * */


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*ex_1  � a classe ex_1.java da classe*/
		
		
		//exercicio2
		/*Ex_2Conta exercicio2 = new Ex_2Conta();
		exercicio2.saldo = 1000;
		exercicio2.deposita(1000);
		exercicio2.saca(1000);
		exercicio2.CalcRendimento();*/
		
		
		//exercicio3
		/*Ex_3Conta exercicio3 = new Ex_3Conta();
		exercicio3.saldo = 1000;
		exercicio3.nome= "Rodrigo";
		exercicio3.agencia = "4002";
		exercicio3.Data= "11/11/2011";
		exercicio3.numero = 4000;
		exercicio3.recuperaDadosParaImpressao();*/
		
		
		//exercicio4
		/*Ex_3Conta exercicio4C1 = new Ex_3Conta();
		exercicio4C1.saldo = 1000;
		exercicio4C1.nome= "Rodrigo";
		exercicio4C1.agencia = "4002";
		exercicio4C1.Data= "11/11/2011";
		exercicio4C1.numero = 4000;
		exercicio4C1.recuperaDadosParaImpressao();
		
		Ex_3Conta exercicio4C2 = new Ex_3Conta();
		exercicio4C2.saldo = 1000;
		exercicio4C2.nome= "Rodrigo";
		exercicio4C2.agencia = "4002";
		exercicio4C2.Data= "11/11/2011";
		exercicio4C2.numero = 4000;
		exercicio4C2.recuperaDadosParaImpressao();
		if	(exercicio4C1	==	exercicio4C2)	{
			System.out.println("\\niguais");
		}else{
			System.out.println("\ndiferentes");								
		}*/
		
		
		
		//exercicio5
		/*Ex_3Conta exercicio5C1 = new Ex_3Conta();
		exercicio5C1.saldo = 1000;
		exercicio5C1.nome= "Rodrigo";
		exercicio5C1.agencia = "4002";
		exercicio5C1.Data= "11/11/2011";
		exercicio5C1.numero = 4000;
		Ex_3Conta exercicio5C2 = new Ex_3Conta();
		exercicio5C2 = exercicio5C1;
		if	(exercicio5C1	==	exercicio5C2)	{
			System.out.println("\niguais");
		}else{
			System.out.println("\ndiferentes");								
		}*/
		
		
		//exercicio6
		/*
		Ex_6Conta exercicio6 = new Ex_6Conta();
		Ex_6Data ex_6Data= new Ex_6Data();
		ex_6Data.ano = 10;
		ex_6Data.mes = 10;
		ex_6Data.dia = 10;
		exercicio6.saldo = 1000;
		exercicio6.nome= "Rodrigo";
		exercicio6.agencia = "4002";
		exercicio6.Data= ex_6Data;
		exercicio6.numero = 4000;
		exercicio6.recuperaDadosParaImpressao();
		*/
		
		
		//exercicio7
		
		Ex_7Conta exercicio7 = new Ex_7Conta();
		Ex_6Data ex_7Data= new Ex_6Data();
		ex_7Data.ano = 10;
		ex_7Data.mes = 10;
		ex_7Data.dia = 10;
		exercicio7.saldo = 1000;
		exercicio7.nome= "Rodrigo";
		exercicio7.agencia = "4002";
		//exercicio7.data= ex_7Data;
		exercicio7.numero = 4000;
		System.out.print("\nData: "+exercicio7.recuperaDadosParaImpressao());
		
		
		
		//exercicio8
		/*
		Ex_7Conta.saldo = 1234;
		Ex_7Conta.calculaRendimento();
		*/
		
		
		
		//exercicio9
		/*Ex_9Conta exercicio9 = new Ex_9Conta();
		Ex_9Data ex_9Data= new Ex_9Data();
		ex_9Data.ano = 10;
		ex_9Data.mes = 10;
		ex_9Data.dia = 10;
		exercicio9.saldo = 1000;
		exercicio9.nome= "Rodrigo";
		exercicio9.agencia = "4002";
		exercicio9.data= ex_9Data;
		exercicio9.numero = 4000;
		System.out.print(" " +exercicio9.recuperaDadosParaImpressao());*/
	}

}
