package ex2;
public class Mes{
        private String nomePessoa;    
	private String nomeMes;
	private double salario;
	private double gastos;
	private double impostos;
        
    public String getNomePessoa() {
        return nomePessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }
	public String getNomeMes() {
		return nomeMes;
	}
	public void setNomeMes(String nomeMes) {
		this.nomeMes = nomeMes;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getGastos() {
		return gastos;
	}
	public void setGastos(double gastos) {
		this.gastos = gastos;
	}
	public double getImpostos() {
		return impostos;
	}
	public void setImpostos(double impostos) {
		this.impostos = impostos;
	}
	public double saldo() {
		double m = this.salario - this.gastos;
		return m;
	}
	public String todosDados(){
                String res = "Nome:"+ getNomePessoa()+ " Mes:" + getNomeMes() + " Salário:" + getSalario() + " Gastos:" + getGastos() + " Impostos:" + getImpostos();
		return res;
	}
}
