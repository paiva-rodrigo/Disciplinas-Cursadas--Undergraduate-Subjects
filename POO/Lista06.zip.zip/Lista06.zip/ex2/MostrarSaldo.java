package ex2;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTextArea;
public class MostrarSaldo extends JDialog {
	JButton jbtFechar;
	JTextArea jtaMS;
	Vector<Mes>pessoas;
	public MostrarSaldo(Vector<Mes>c) {
		pessoas = c;
		getContentPane().setLayout(null);
		setTitle("Dados resumidos");
		Handler obj = new Handler(); 
		jbtFechar = new JButton("Voltar");
		jbtFechar.setBounds(10, 10, 100, 40);
		jbtFechar.addActionListener(obj);
		add(jbtFechar);
		
		jtaMS = new JTextArea();
		jtaMS.setBounds(50, 100, 350, 200);
		jtaMS.setText(dadosFormatados());
		add(jtaMS);
		
		setBounds(120,120,450,450);
		setVisible(true);
		setModal(true);
	}
	public String dadosFormatados() {
		String m = "";
		for(int i=0;i<pessoas.size();i++) {
			m = m + "\n Nome: " + pessoas.get(i).getNomePessoa()+ " Saldo:" + pessoas.get(i).saldo();
		}
		return m;
	}
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtFechar) {
				setVisible(false);
			}
		}
	}
}