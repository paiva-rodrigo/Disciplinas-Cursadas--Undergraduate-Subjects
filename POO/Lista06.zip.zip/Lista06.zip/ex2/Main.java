package ex2;
import exercicio2.ExibirMedia;
import exercicio2.ExibirNomeSaldo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class Main extends JFrame{
	JButton jbtCP, jbtExibirMedia, jbtExibirNomeSaldo, jbtExibirTodos;
	Vector <Mes> pessoas = new Vector<Mes>();
	Cadastro p = new Cadastro(this);
	public Main(){
		getContentPane().setLayout(null);
		setTitle("Tela Principal");
		Handler obj = new Handler();
		
                //botoes
		jbtCP = new JButton("Cadastro pessoas");
		jbtCP.setBounds(10,10,150,30);
		jbtCP.addActionListener(obj);
		add(jbtCP);
		jbtExibirMedia = new JButton("Mostrar media");
		jbtExibirMedia.setBounds(10,60,150,30);
		jbtExibirMedia.addActionListener(obj);
		add(jbtExibirMedia);
		jbtExibirNomeSaldo = new JButton("Mostrar nome e saldo");
		jbtExibirNomeSaldo.setBounds(10,110,200,30);
		jbtExibirNomeSaldo.addActionListener(obj);
		add(jbtExibirNomeSaldo);
		jbtExibirTodos = new JButton("Mostrar todos os dados");
		jbtExibirTodos.setBounds(10, 160, 200, 30);
		jbtExibirTodos.addActionListener(obj);
		add(jbtExibirTodos);
		
		setBounds(100,100,500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void cadastra(Mes c){
		pessoas.add(c);
	}

	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource()==jbtCP){
				p.setVisible(true);
			}
			if(e.getSource()==jbtExibirMedia){
				new MostrarMedia(pessoas);
			}
			if(e.getSource()==jbtExibirNomeSaldo) {
				new MostrarSaldo(pessoas);
			}
			if(e.getSource() == jbtExibirTodos) {
				new MostrarTudo(pessoas);
			}
		}
	}
    public static void main(String[] args)  {
        System.out.print("rodando");
        new Main();
        
    }
}
