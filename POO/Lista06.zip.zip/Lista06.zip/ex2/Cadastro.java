package ex2;
import java.awt.event.*;
import javax.swing.*;
public class Cadastro extends JDialog {
	JButton jbtCadastrar1, jbtFechar1;
	JTextField jtfNomeP, jtfNomeM, jtfSalario, jtfGastos, jtfImpostos;
        JLabel jlNomeP, jlNomeM, jlSalario, jlGastos, jlImpostos;
	Main pc;
	public Cadastro(Main c) {
		this.pc = c;
		getContentPane().setLayout(null);
		Handler obj = new Handler();
		setTitle("Cadastro");
                
                //Parte dso botoes
		jbtCadastrar1 = new JButton("Cadastrar");
		jbtCadastrar1.setBounds(10,10,250,30);
		jbtCadastrar1.addActionListener(obj);
		add(jbtCadastrar1);
		jbtFechar1 = new JButton("Voltar");
		jbtFechar1.setBounds(10,310,150,30);
		jbtFechar1.addActionListener(obj);
		add(jbtFechar1);
                
                //parte dos text field
		jtfNomeP = new JTextField();
		jtfNomeP.setText("");
		jtfNomeP.setBounds(150,60,150,30);
		add(jtfNomeP);
		jtfNomeM = new JTextField();
		jtfNomeM.setText("");
		jtfNomeM.setBounds(150,110,150,30);
		add(jtfNomeM);
		jtfSalario = new JTextField();
		jtfSalario.setText("");
		jtfSalario.setBounds(150,160,150,30);
		add(jtfSalario);
		jtfGastos = new JTextField();
		jtfGastos.setText("");
		jtfGastos.setBounds(150,210,150,30);
		add(jtfGastos);
		jtfImpostos = new JTextField();
		jtfImpostos.setText("");
		jtfImpostos.setBounds(150,260,150,30);
		add(jtfImpostos);
                
                //text label
                jlNomeP = new JLabel();
                jlNomeP.setText("Nome da Pessoa:");
                jlNomeP.setBounds(10, 60, 150, 30);
                add(jlNomeP);
                jlNomeM = new JLabel();
                jlNomeM.setText("Nome do Mes:");
                jlNomeM.setBounds(10, 110, 150, 30);
                add(jlNomeM);
                jlSalario = new JLabel();
                jlSalario.setText("Salario:");
                jlSalario.setBounds(10, 160, 150, 30);
                add(jlSalario);
                jlImpostos = new JLabel();
                jlImpostos.setText("Impostos:");
                jlImpostos.setBounds(10, 210, 150, 30);
                add(jlImpostos);
                jlGastos = new JLabel();
                jlGastos.setText("Gastos:");
                jlGastos.setBounds(10, 260, 150, 30);
                add(jlGastos);
                
		setBounds(10,10,400,400);
	}
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
                if(e.getSource() == jbtCadastrar1){
                        Mes aux = new Mes();
                        aux.setNomePessoa(jtfNomeP.getText());
                        aux.setNomeMes(jtfNomeM.getText());
                        aux.setSalario(Double.parseDouble(jtfSalario.getText()));
                        aux.setGastos(Double.parseDouble(jtfGastos.getText()));
                        aux.setImpostos(Double.parseDouble(jtfImpostos.getText()));
                        pc.cadastra(aux);
                        jtfNomeP.setText("");
                        jtfNomeM.setText("");
                        jtfSalario.setText("");
                        jtfGastos.setText("");
                        jtfImpostos.setText("");
                }
			if(e.getSource() == jbtFechar1){
				setVisible(false);
			}
		}
	}
}
