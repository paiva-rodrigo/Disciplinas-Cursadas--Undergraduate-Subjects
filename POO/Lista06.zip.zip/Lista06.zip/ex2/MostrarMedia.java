package ex2;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;

public class MostrarMedia extends JDialog {
	JButton jbtFechar;
	JTextArea jtaMedia;
	Vector<ex2.Mes>pessoas;
	public MostrarMedia(Vector<ex2.Mes>c) {
		pessoas = c;
		getContentPane().setLayout(null);
		setTitle("Dados resumidos");
		Handler obj = new Handler(); 
		jbtFechar = new JButton("Voltar");
		jbtFechar.setBounds(10, 10, 100, 40);
		jbtFechar.addActionListener(obj);
		add(jbtFechar);
		
		jtaMedia = new JTextArea();
		jtaMedia.setBounds(50, 100, 350, 200);
		jtaMedia.setText(dadosFormatados());
		add(jtaMedia);
		
		setBounds(120,120,450,450);
		setVisible(true);
		setModal(true);
	}
	
	public String dadosFormatados() {
		String m = "";
		double med=0, a=0;
		for(int i=0;i<pessoas.size();i++) {
			med =+ pessoas.get(i).getSalario();
			a++;
		}
		m = "Saldo:" + (med/a);
		return m;
	}
	
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtFechar) {
				setVisible(false);
			}
		}
	}
}
