package ex3;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;
public class MostrarVeiculo extends JDialog{
	JButton jbtFechar;
	JTextArea jtaTDados;
	Vector<Veiculo> veiculos;
        JLabel jlnometela;
	public MostrarVeiculo(Vector<Veiculo> v) {
		veiculos = v;
		getContentPane().setLayout(null);
		setTitle("Dados");
		Handler obj = new Handler(); 
                
                //textlabel
                jlnometela = new JLabel();
                jlnometela.setText("Todos os Carros Cadastrados:");
                jlnometela.setBounds(150, 40, 300, 100);
                add(jlnometela);
                
                //Botoes
		jbtFechar = new JButton("Voltar");
		jbtFechar.setBounds(200, 10, 100, 60);
		jbtFechar.addActionListener(obj);
		add(jbtFechar);
		jtaTDados = new JTextArea();
		jtaTDados.setBounds(50, 100, 350, 200);
		jtaTDados.setText(dados());
		add(jtaTDados);
		setBounds(120,120,450,450);
		setVisible(true);
		setModal(true);
	}

	public String dados() {
		String p = "";
		for(int i=0;i<veiculos.size();i++) {
			p = p + "\n" + veiculos.get(i).todosDados();
		}
		return p;
	}
	
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtFechar) {
				setVisible(false);
			}
		}
	}
}
