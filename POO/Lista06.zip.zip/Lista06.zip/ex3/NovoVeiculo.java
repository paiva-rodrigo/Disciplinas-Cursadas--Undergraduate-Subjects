package ex3;
import java.awt.event.*;
import javax.swing.*;
public class NovoVeiculo extends JDialog {
	JButton jbtCadastrar1, jbtFechar1;
        JLabel jlnome,jlano,jlcadVeic;
	JTextField jtfNome, jtfAno;
	Main mn;
	public NovoVeiculo(Main r) {
		this.mn = r;
		getContentPane().setLayout(null);
		Handler obj = new Handler();
		setTitle("Cadastro de Veiculos");
                
                //botoes
		jbtCadastrar1 = new JButton("Cadastrar");
		jbtCadastrar1.setBounds(10,10,250,30);
		jbtCadastrar1.addActionListener(obj);
		add(jbtCadastrar1);
		jbtFechar1 = new JButton("Voltar");
		jbtFechar1.setBounds(10,310,150,30);
		jbtFechar1.addActionListener(obj);
		add(jbtFechar1);
                
                //textfield
		jtfNome = new JTextField();
		jtfNome.setText("");
		jtfNome.setBounds(200,60,150,30);
		add(jtfNome);
		jtfAno = new JTextField();
		jtfAno.setText("");
		jtfAno.setBounds(200,110,150,30);
		add(jtfAno);
                
                //textlabel
                jlano = new JLabel();
                jlano.setText("Ano de fabricação:");
                jlano.setBounds(50, 110, 150, 30);
                add(jlano);
                jlnome = new JLabel();
		jlnome.setText("Nome do carro:");
                jlnome.setBounds(50, 60, 150, 30);
                add(jlnome);
                jlcadVeic = new JLabel();
		jlcadVeic.setText("Cadastro de Veiculos");
                jlcadVeic.setBounds(90, 200, 150, 30);
                add(jlcadVeic);
                
		setBounds(10,10,400,400);
                
	}
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtCadastrar1){
				Veiculo aux = new Veiculo();
				aux.setNome(jtfNome.getText());
				aux.setAno(Integer.parseInt(jtfAno.getText()));
				mn.cadastra(aux);
				jtfNome.setText("");
				jtfAno.setText("");
			}
			if(e.getSource() == jbtFechar1){
				setVisible(false);
			}
		}
	}
}
