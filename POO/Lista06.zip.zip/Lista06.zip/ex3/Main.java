package ex3;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFrame;
public class Main extends JFrame {
    JButton CC, MostrarCarros, Cancelar;
    Vector <Veiculo> veiculos = new Vector<Veiculo>();
    NovoVeiculo v = new NovoVeiculo(this);
    public Main(){
        getContentPane().setLayout(null);
        setTitle("Principal");
        Handler objeto = new Handler();

        //Parte dos botoes
        CC = new JButton("Cadastro de carros");
        CC.setBounds(10,10,150,30);
        CC.addActionListener(objeto);
        add(CC);	
        MostrarCarros = new JButton("Exibir carros");
        MostrarCarros.setBounds(10,60,150,30);
        MostrarCarros.addActionListener(objeto);
        add(MostrarCarros);
        Cancelar = new JButton("Cancelar");
        Cancelar.setBounds(10,110,150,30);
        Cancelar.addActionListener(objeto);
        add(Cancelar);
        
        setBounds(100,100,500,500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public class Handler implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==CC){
                    v.setVisible(true);
            }
            if(e.getSource()==MostrarCarros){
                    new MostrarVeiculo(veiculos);
            }
            if(e.getSource()==Cancelar) {
                    setVisible(false);
            }
        }
    }
    public static void main(String[] args) {
        new Main();
    }
    public void cadastra(Veiculo c){
            veiculos.add(c);
    }


    
}
