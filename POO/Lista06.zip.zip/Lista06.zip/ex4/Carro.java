package ex4;

public class Carro extends Veiculo {
	private long chassi;

	public long getChassi() {
		return chassi;
	}

	public void setChassi(long chassi) {
		this.chassi = chassi;
	}
	public String todosDados() {
		return " Placa:"+ getPlaca() + " Cor:" + getCor() + " Chassi:" + getChassi();
	}
}
