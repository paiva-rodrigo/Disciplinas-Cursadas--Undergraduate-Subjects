package ex4;
public class Moto extends Veiculo {
	private int cilindadras;
	public int getCilindadras() {
		return cilindadras;
	}

	public void setCilindadras(int cilindadras) {
		this.cilindadras = cilindadras;
	}
	public String todosDados() {
		return " Placa:"+ getPlaca() + " Cor:" + getCor() + " Cilindadras:" + getCilindadras();
	}
}