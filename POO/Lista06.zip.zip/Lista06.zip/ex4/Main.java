package ex4;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Main extends JFrame {
	JButton jbtCC, jbtCM, jbtCCa,jbtExibirDados, jbtCancelar;
	Vector <Veiculo> veiculos = new Vector<Veiculo>();
	NewCaminhao nvc = new NewCaminhao(this);
	NewCarro nvca = new NewCarro(this);
	NewMoto nvm = new NewMoto(this);
	public Main(){
            getContentPane().setLayout(null);
            setTitle("Tela Principal");
            Handler obj = new Handler();

            //parte dos botoes
            jbtCC = new JButton("Cadastro de carro");
            jbtCC.setBounds(10,10,150,30);
            jbtCC.addActionListener(obj);
            add(jbtCC);
            jbtCM = new JButton("Cadastro de moto");
            jbtCM.setBounds(10,60,150,30);
            jbtCM.addActionListener(obj);
            add(jbtCM);
            jbtCCa = new JButton("Cadastro de caminhao");
            jbtCCa.setBounds(10,110,200,30);
            jbtCCa.addActionListener(obj);
            add(jbtCCa);
            jbtExibirDados = new JButton("Exibir dados");
            jbtExibirDados.setBounds(10,160,150,30);
            jbtExibirDados.addActionListener(obj);
            add(jbtExibirDados);
            jbtCancelar = new JButton("Cancelar");
            jbtCancelar.setBounds(10,210,150,30);
            jbtCancelar.addActionListener(obj);
            add(jbtCancelar);

            setBounds(100,100,500,500);
            setVisible(true);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void cadastra(Veiculo c){
		veiculos.add(c);
	}

	public class Handler implements ActionListener{
            public void actionPerformed(ActionEvent e){
                    if(e.getSource()==jbtCC){
                            nvca.setVisible(true);
                    }
                    if(e.getSource()==jbtCM){
                            nvm.setVisible(true);
                    }
                    if(e.getSource()==jbtCCa){
                            nvc.setVisible(true);
                    }
                    if(e.getSource()==jbtExibirDados){
                            new Dados(veiculos);
                    }
                    if(e.getSource()==jbtCancelar) {
                            setVisible(false);
                    }
            }
	}
	public static void main(String[] args) {
		new Main();
	}
}
