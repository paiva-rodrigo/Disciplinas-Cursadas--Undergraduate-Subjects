package ex4;
import java.awt.event.*;
import javax.swing.*;

public class NewCaminhao extends JDialog{
	JButton jbtCadastrar1, jbtFechar1;
        JLabel jlcadastro,jlplaca,jlnumeixos,jlcor,jlcarga;
	JTextField jtfPlaca, jtfCor, jtfNumEixos, jtfCarga;
	Main mn;
	public NewCaminhao(Main r) {
		this.mn = r;
		getContentPane().setLayout(null);
		Handler obj = new Handler();
		setTitle("Cadastro de veiculos");
                
                //parte dos butoes
		jbtCadastrar1 = new JButton("Cadastrar");
		jbtCadastrar1.setBounds(10,10,250,30);
		jbtCadastrar1.addActionListener(obj);
		add(jbtCadastrar1);
		jbtFechar1 = new JButton("Voltar");
		jbtFechar1.setBounds(10,310,150,30);
		jbtFechar1.addActionListener(obj);
		add(jbtFechar1);
                
                
                //parte dos TextField
		jtfPlaca = new JTextField();
		jtfPlaca.setText("");
		jtfPlaca.setBounds(150,60,150,30);
		add(jtfPlaca);
		jtfCor = new JTextField();
		jtfCor.setText("");
		jtfCor.setBounds(150,110,150,30);
		add(jtfCor);
		jtfNumEixos = new JTextField();
		jtfNumEixos.setText("");
		jtfNumEixos.setBounds(150,160,150,30);
		add(jtfNumEixos);
		jtfCarga = new JTextField();
		jtfCarga.setText("");
		jtfCarga.setBounds(150,210,150,30);
		add(jtfCarga);
                
                //Parte dos TextLabel
		jlcadastro = new JLabel();
                jlcadastro.setText("Cadastro de Caminhao");
                jlcadastro.setBounds(100, 200, 150, 150);
                add(jlcadastro);
                jlcarga = new JLabel();
                jlcarga.setText("Carga");
                jlcarga.setBounds(10, 210, 150, 30);
                add(jlcarga);
                
                jlcor = new JLabel();
                jlcor.setText("Cor");
                jlcor.setBounds(10, 110, 150, 30);
                add(jlcor);
                jlnumeixos = new JLabel();
                jlnumeixos.setText("Numero Eixos");
                jlnumeixos.setBounds(10, 160, 150, 30);
                add(jlnumeixos);
                jlplaca = new JLabel();
                jlplaca.setText("Placa");
                jlplaca.setBounds(10, 60, 150, 30);
                add(jlplaca);
		setBounds(10,10,400,400);
	}
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtCadastrar1){
				Caminhao aux = new Caminhao();
				aux.setPlaca(jtfPlaca.getText());
				aux.setCor(jtfCor.getText());
				aux.setNum_eixos(Integer.parseInt(jtfNumEixos.getText()));
				aux.setCarga(Double.parseDouble(jtfCarga.getText()));
				mn.cadastra(aux);
				jtfPlaca.setText("");
				jtfCor.setText("");
				jtfNumEixos.setText("");
				jtfCarga.setText("");
			}
			if(e.getSource() == jbtFechar1){
				setVisible(false);
			}
		}
	}
}
