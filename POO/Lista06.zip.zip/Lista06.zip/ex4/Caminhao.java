package ex4;
public class Caminhao extends Veiculo {
	private int num_eixos;
	private double carga;
	public int getNum_eixos() {
		return num_eixos;
	}
	public void setNum_eixos(int numeixos) {
		this.num_eixos = numeixos;
	}
	public double getCarga() {
		return carga;
	}
	public void setCarga(double carga) {
		this.carga = carga;
	}
	public String todosDados() {
            String res = " Placa:"+ getPlaca() + " Cor:" + getCor() + " N�mero de eixos:" + getNum_eixos() + " Carga:" + getCarga();
            return res;
	}
}