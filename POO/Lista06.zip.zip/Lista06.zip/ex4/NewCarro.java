package ex4;
import java.awt.event.*;
import javax.swing.*;
public class NewCarro extends JDialog {
	JButton jbtCadastrar1, jbtFechar1;
        JLabel jlcadastro,jlcor,jlplaca,jlchassi;
	JTextField jtfPlaca, jtfCor, jtfChassi;
	Main mn;
	public NewCarro(Main r) {
		this.mn = r;
		getContentPane().setLayout(null);
		Handler obj = new Handler();
		setTitle("Cadastro de veiculos");
                
                //botoes 
		jbtCadastrar1 = new JButton("Cadastrar");
		jbtCadastrar1.setBounds(10,10,250,30);
		jbtCadastrar1.addActionListener(obj);
		add(jbtCadastrar1);
		jbtFechar1 = new JButton("Voltar");
		jbtFechar1.setBounds(10,310,150,30);
		jbtFechar1.addActionListener(obj);
		add(jbtFechar1);
                
                //parte dos test field
		jtfPlaca = new JTextField();
		jtfPlaca.setText("");
		jtfPlaca.setBounds(150,60,150,30);
		add(jtfPlaca);
		jtfCor = new JTextField();
		jtfCor.setText("");
		jtfCor.setBounds(150,110,150,30);
		add(jtfCor);
		jtfChassi = new JTextField();
		jtfChassi.setText("");
		jtfChassi.setBounds(150,160,150,30);
		add(jtfChassi);
		
                //parte dos textlabel
                jlcadastro = new JLabel();
                jlcadastro.setText("Cadastro de Carro");
                jlcadastro.setBounds(100, 200, 150, 150);
                add(jlcadastro);
                jlcor = new JLabel();
                jlcor.setText("Cor");
                jlcor.setBounds(10,110,150,30);
                add( jlcor);
                jlplaca = new JLabel();
                jlplaca.setText("Placa");
                jlplaca.setBounds(10,60,150,30);
                add(jlplaca);
                jlchassi = new JLabel();
                jlchassi.setText("Chassi");
                jlchassi.setBounds(10,160,150,30);
                add(jlchassi);
		setBounds(10,10,400,400);
	}
	public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource() == jbtCadastrar1){
				Carro aux = new Carro();
				aux.setPlaca(jtfPlaca.getText());
				aux.setCor(jtfCor.getText());
				aux.setChassi(Long.parseLong(jtfChassi.getText()));
				mn.cadastra(aux);
				jtfPlaca.setText("");
				jtfCor.setText("");
				jtfChassi.setText("");
			}
			if(e.getSource() == jbtFechar1){
				setVisible(false);
			}
		}
	}
}
