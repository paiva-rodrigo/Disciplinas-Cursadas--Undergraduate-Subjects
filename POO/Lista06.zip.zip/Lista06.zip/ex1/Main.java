package ex1;

public class Main {
    public static void main(String[] args) {
        Retangulo r1 = new Retangulo();
    }
    
}
