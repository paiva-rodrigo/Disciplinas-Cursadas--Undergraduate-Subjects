package ex1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MostraArea extends JFrame{
    
    public MostraArea(float larg,float comp){
     getContentPane().setLayout(null);
     setTitle("Area do retangulo:");
     JLabel jlarea = new JLabel();
     jlarea.setText("A area do retangulo vale: "+(larg*comp));
     jlarea.setBounds(25, 10, 200, 30);
     add(jlarea);
     setBounds(20,20,500,600);
     setVisible(true);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

