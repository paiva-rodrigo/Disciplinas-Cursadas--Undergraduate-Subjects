package ex1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Retangulo extends JFrame{
    MostraArea mostarea;
    Handler obj = new Handler();
    float larg,comp;
    
    JLabel jblarg = new JLabel();
    JLabel jbcomp = new JLabel();
    JButton btncomp = new JButton();
    JTextField jtlarg = new JTextField();
    JTextField jtcomp = new JTextField();
    
    public Retangulo(){
        //Textos
    getContentPane().setLayout(null);
    jbcomp.setText("Comprimento:");
    jbcomp.setBounds(25, 10, 150, 30);
    add(jbcomp);
    jblarg.setText("Largura:");
    jblarg.setBounds(150, 10, 150, 30);
    add(jblarg);
    
        //Butoes
    btncomp.setText("Confirmar");
    btncomp.setBounds(90, 100, 100, 25);
    btncomp.addActionListener(obj); 
    add(btncomp);
    
        //Caixas de entrada
    jtlarg.setBounds(150, 70, 100, 25);
    jtcomp.setBounds(25, 70, 100, 25);
    add(jtcomp);
    add(jtlarg);
    setTitle("Dados sobrea a area do retangulo:");    
    setBounds(20,20,500,600);
    setVisible(true);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public void area(){
     larg = Float.valueOf(jtlarg.getText()).floatValue();
     comp = Float.valueOf(jtcomp.getText()).floatValue();
     System.out.print("Area: "+(larg*comp));   
     mostarea = new MostraArea(larg,comp);
    }
    public class Handler implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(e.getSource()==btncomp){
				visibilidade();
                                area();
			}
		}
	}
    private void visibilidade() {
        setVisible(false);
    }
}
