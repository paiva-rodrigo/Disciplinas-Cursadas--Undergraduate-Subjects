#include<iostream>
#include<fstream>
using namespace std;
   double cod(double c,double s){
      if(c!=3 ||c!=2 ||c!=1 ){
       return s*1.4;
      }
      else if(c==1){
       return s*1.1;
      } 
      else if(c==2){
       return s*1.2; 
      }
       else{
       return s*1.3;
      } 
   }
   int main(){
      double co, sal,res;
      string  nome;
      ifstream  ler("questao_12.txt");
      ofstream escrever("novos_salarios.txt");
      while(ler>>nome){
       ler>>sal;
       ler>>co;
       res=cod(co,sal);
       cout<<nome<<" ficou com um salario de "<<res<<" reais apos o aumento\n";
       escrever.open("novos_salarios.txt",ios::app);
       escrever<<nome<<" ficou com um salario de "<<res<<" reais apos o aumento\n";
       escrever.close();
      }
    return 0;
   }
