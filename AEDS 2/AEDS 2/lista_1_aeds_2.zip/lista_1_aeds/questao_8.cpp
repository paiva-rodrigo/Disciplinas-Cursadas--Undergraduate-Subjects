#include<iostream>
#include<fstream>
 using namespace std;
 int main(){
 int num;
  cout<<"Digite um numero para saber quantos estao abaixo do seu valo no arquivo de texto:\n";
  cin>>num;
 int r=0,menor=0;
 float n,med=0;
   ifstream nun("questao_8.txt");
    while(nun>>n && r<20){
       med=med+n;
       if(n<num){
        menor++;
       }
       r++;
    }
  cout<<"sao "<<menor<<" que tem valo menor que "<<num;
  cout<<"\nO valor da media dos numeros nesse arquivo de texto e: "<<med/20;
 }
