#include<iostream>
 using namespace std;
 float serie(float a){
  cout<<"+ (1+"<<a<<"^2) / "<<a<<" ";
  if(a==1) 
     return 2;
  else 
     return ((a*a)+1)/a+serie(a-1);
 }
 int main(){
  float a;
  cout<<"Digite o termo  positivo n que ira  ser o valor limitante da express�o 2+(2^2+1)/2+[...]+(n^2+1)/n :";
  cin>>a;
  cout<<"\nO valor da funcao para n="<<a<<" e:\n "<<serie(a);
 }
