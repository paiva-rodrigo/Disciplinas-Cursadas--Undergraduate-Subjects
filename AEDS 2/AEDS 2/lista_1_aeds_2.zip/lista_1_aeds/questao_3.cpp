#include<iostream>
 using namespace std;
  double har(double t){
    if(t==1){
       return 1;
    }
    else{
       return (1/t)+har(t-1);
    } 
  }
  int main(){
   double r;
   r=1;
     while(r!=0){
       cout<<"\nDigite qual n-esimo termo o da sequencia harmonica h(n)=1/1+1/2+[...]+1/n"\
       " voce quer saber  digite 0 se nao quer saber: digite 0 se quer parar: ";
       cin>>r;
       double res=har(r);
       cout<<"O valor do harmonico de ordem "<<r<<" e igual a :"<<res;
     }
   return 0;
  }
