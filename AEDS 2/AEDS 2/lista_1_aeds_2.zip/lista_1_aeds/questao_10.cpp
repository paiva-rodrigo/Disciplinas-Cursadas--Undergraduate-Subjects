#include <fstream>
#include <iostream>
   using namespace std;
     double notap(float a,float b){
      return (a+b)*0.7/2; 
     }
     double notat(float a,float b,float c,float d){
      return (a+b+c+d)*0.3/4 ; 
     }
     int main(){
      string  nome;
      int p1,p2,t1,t2,t3,t4;
      ifstream  ler("notas.txt");
      int notafinal; 
        while(ler>>nome){
         ler>>p1;
         ler>>p2;
         ler>>t1;
         ler>>t2;
         ler>>t3;
         ler>>t4;
         notafinal=notap(p1,p2)+notat(t1,t2,t3,t4);
          cout<<"Nome:"<<nome<<"   nota:"<<notafinal<<endl;
         }
       return 0; 
      }
