#include<iostream>
using namespace std;
int main(){
 int v;
 cout<<"Digite o tamanho de um vetor:";
 cin>>v;
 int *vet=new int[v];
  for(int r=0;r<v;r++){
   cout<<"Digite o "<<r+1<<" termo do vetor:";
   cin>>*(r+vet);
  }
 cout<<"\nO vetor e:"<<*(vet);
 int maior=*(vet);
 int menor=*(vet);
 int media=*(vet);
  for(int r=1;r<v;r++){
   cout<<" "<<*(r+vet);
   if(*(r+vet)>*(vet)){
    maior=*(r+vet);
   }
   if(*(r+vet)<*(vet)){
    menor=*(r+vet);
   }
   media+=*(r+vet);
  }
 cout<<"\nO valor da media desses valores e igual a: "<<(media)/v;
 cout<<"\nO valor do menor numero do vetor e: "<<menor;
 cout<<"\nO valor do maior numero do vetor e: "<<maior;  
  
 return 0;
}
