#include <fstream>
#include <iostream>
  using namespace std;
   int main(){
   int ro;
   cout<<"voce deseja codificar os dados ou decodificar os dados de um arquivo de texto?"\
   " Digite (1) para codificar e (0) para decodificar :\n";
   cin>>ro;
   string  nome1,nome2;
   if(ro==1){
   cout<<"Digite o nome do arquivo que voce quer ler:";
   cin>>nome1;
   cout<<"\nDigite o nome do arquivo em que voce quer gravar os dados codidicados:";
   cin>>nome2;
   ofstream esc(nome2.c_str());
   ifstream ler(nome1.c_str());
   char r;
    while(ler.get(r)){
      if(r=='a')   esc<<"v";
      else if(r=='b')   esc<<"t";
      else if(r=='c')   esc<<"g";
      else if(r=='D')   esc<<"M";
      else if(r=='e')   esc<<"b";
      else if(r=='F')   esc<<"Z";
      else if(r=='g')   esc<<"a";
      else if(r=='h')   esc<<"i";
      else if(r=='i')   esc<<"w";
      else if(r=='j')   esc<<"s";
      else if(r=='k')   esc<<"p";
      else if(r=='l')   esc<<"f";
      else if(r=='m')   esc<<"r";
      else if(r=='n')   esc<<"q";
      else if(r=='o')   esc<<"e";
      else if(r=='p')   esc<<"c";
      else if(r=='Q')   esc<<"X";
      else if(r=='r')   esc<<"u";
      else if(r=='S')   esc<<"K";
      else if(r=='t')   esc<<"n";
      else if(r=='u')   esc<<"o";
      else if(r=='v')   esc<<"l";
      else if(r=='w')   esc<<"y";
      else if(r=='x')   esc<<"h";
      else if(r=='y')   esc<<"j";
      else if(r=='z')   esc<<"d";
      else if(r==' ')   esc<<".";
      else if(r==',')   esc<<"?";
      else if(r=='.')   esc<<"!";
      else if(r=='!')   esc<<":";
      else if(r=='?')   esc<<" ";
      else if(r==':')   esc<<",";
      else if(r=='4')   esc<<"1";
      else if(r=='1')   esc<<"7";
      else if(r=='2')   esc<<"4";
      else if(r=='3')   esc<<"6";
      else if(r=='5')   esc<<"3"; 
      else if(r=='6')   esc<<"9";
      else if(r=='7')   esc<<"5";
      else if(r=='8')   esc<<"0"; 
      else if(r=='9')   esc<<"2";
      else if(r=='0')   esc<<"8";
      else if(r==' ')   esc<<" ";
      else esc<<r;
    }
  esc.close();
  ifstream  ler2(nome2.c_str());
  string  nome3;
    while(ler2>>nome3){
     cout<<nome3<<"  ";
    }
   }
   else if(ro==0){
   cout<<"Digite o nome do arquivo que voce quer decodificar:";
   cin>>nome1;
   cout<<"\nDigite o nome do arquivo em que voce quer gravar os dados descodidicados:";
   cin>>nome2;
   ofstream esc(nome2.c_str());
   ifstream ler(nome1.c_str());
   char r;
    while(ler.get(r)){
      if(r=='v')   esc<<"a";
      else if(r=='t')   esc<<"b";
      else if(r=='g')   esc<<"c";
      else if(r=='M')   esc<<"D";
      else if(r=='b')   esc<<"e";
      else if(r=='Z')   esc<<"F";
      else if(r=='a')   esc<<"g";
      else if(r=='i')   esc<<"h";
      else if(r=='w')   esc<<"i";
      else if(r=='s')   esc<<"j";
      else if(r=='p')   esc<<"k";
      else if(r=='f')   esc<<"l";
      else if(r=='r')   esc<<"m";
      else if(r=='q')   esc<<"n";
      else if(r=='e')   esc<<"o";
      else if(r=='c')   esc<<"p";
      else if(r=='X')   esc<<"Q";
      else if(r=='u')   esc<<"r";
      else if(r=='K')   esc<<"S";
      else if(r=='n')   esc<<"t";
      else if(r=='o')   esc<<"u";
      else if(r=='l')   esc<<"v";
      else if(r=='y')   esc<<"w";
      else if(r=='h')   esc<<"x";
      else if(r=='j')   esc<<"y";
      else if(r=='d')   esc<<"z";
      else if(r=='.')   esc<<" ";
      else if(r=='!')   esc<<".";
      else if(r=='?')   esc<<",";
      else if(r==':')   esc<<"!";
      else if(r==' ')   esc<<"?";
      else if(r==',')   esc<<":";
      else if(r=='7')   esc<<"1";
      else if(r=='6')   esc<<"3";
      else if(r=='4')   esc<<"2";
      else if(r=='1')   esc<<"4";
      else if(r=='3')   esc<<"5"; 
      else if(r=='9')   esc<<"6";
      else if(r=='5')   esc<<"7";
      else if(r=='0')   esc<<"8"; 
      else if(r=='2')   esc<<"9";
      else if(r=='8')   esc<<"0";
      else if(r==' ')   esc<<" ";
      else esc<<r;
    }
    esc.close();
  ifstream  ler2(nome2.c_str());
  string  nome3;
    while(ler2>>nome3){
     cout<<nome3<<"  ";
    }
   } 
   return 0;
  }
