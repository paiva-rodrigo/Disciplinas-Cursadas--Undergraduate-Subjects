#include<iostream>
 using namespace std;
  int h(int m,int n){
   if(m==1){
      return m+1;
   }     
   if(n==1){
      return n+1;
   }
   else if(m>1 || n>1 ){
      return h(m,n-1)+h(m-1,n);     
  }
 }
 int main(){
   int a,b;
   cout<<"Digite o valor de um numero:";
   cin>>a;
   cout<<"Digite o valor de um segundo numero:";
   cin>>b;
   cout<<"O resultado e  "<<h(a,b);
 return 0;
  }
