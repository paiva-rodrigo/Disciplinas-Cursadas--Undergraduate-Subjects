#include <fstream>
#include <iostream>
   using namespace std;
   int anos(int a){
      return a*5; 
   }
   int filho(int f){
    if(f<=3){
     return f*15;
    }
    else{
     return 45;
    }     
   }
   int ser(int s){
    return 20*s;
   }
   int main(){
     int idade,fil,serv;
     string nome;
     int t=1;
     while(t=1){
     cout<<"Qual e o seu nome? ";
     cin>>nome;
     cout<<"Qual a sua idade? ";
     cin>>idade;
     cout<<"Quantos filhos voce tem? ";
     cin>>fil;
     cout<<"Quantos anos de servico  voce tem? ";
     cin>>serv;
     int bonus;
     bonus=ser(serv)+anos(idade)+filho(fil);  
     ofstream emp;
     emp.open ("exercicio_11.txt",ios::app);
     emp<<nome<<"tem um bonus de "<<bonus<<"reais\n";
     emp.close();
     cout<<"\nExiste um proximo empregado? (1) para sim, (0)para nao :";
     cin>>t;
     }
     
   }
