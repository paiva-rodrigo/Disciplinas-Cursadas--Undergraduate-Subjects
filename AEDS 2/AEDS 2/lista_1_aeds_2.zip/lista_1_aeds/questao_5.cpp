#include<iostream>
 using namespace std;
 double pot(double a,double b){
   if(b==0){
        return 1;
   } 
   else{
     if(b>0){
         return a*pot(a,b-1) ;
     }     
     else{
       return a*pot(a,b+1) ;
     }   
   }
 }
 int main(){
  double x,y,num;
  int a;
  cout<<"\nDeseja fazer o calculo de uma nova  potencia? (digite 1 para sim e 0  para nao):";
  cin>>a;
  while(a==1){
  cout<<"\nDigite o numero que sera a base de uma potencia:";
  cin>>x;
  cout<<"Digite o numero que sera o expoente dessa base:";
  cin>>y;
  cout<<"O valo de "<<x<<"^"<<y<<" e:";
  num=pot(x,y);
    if(y>=0){
      cout<<num ;
    }
    else{
      cout<<1/(num);
    }
  cout<<"\nDeseja fazer o calculo de unova ma potenia? (digite 1 para sim e 0  para nao)";
  cin>>a;
    } 
 return 0;
 }
