#include<iostream>
#include<fstream>
using namespace std;
  int main(){
     char arq[50],pal[50];
     int r=0;
     cout<<"Digite o nome do arquivo que voce quer que seja lido e coloque.txt no final:";
     cin.getline(arq,50);
     cout<<"Digite uma palavra para saber quantas vezes ela esta nesse arquivo de texto:";
     cin.getline(pal,50);
     string  palavra;
     ifstream  ler(arq);
     while(ler>>palavra){
      if(palavra==pal)
       r++;
     }
     cout <<"A palavra "<<pal<<" apareceu "<<r<<" vezes no arquivo de texto "<<arq;
   return 0;
  }
