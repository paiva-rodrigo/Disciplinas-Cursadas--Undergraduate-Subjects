#include<iostream>
#include<fstream>
 using namespace std;
 int main(){
    int r;
    ifstream ler("exercicio_9.txt");
    ofstream par("par.txt");
    ofstream impar("impar.txt");
    while(ler>>r){
      if(r%2==0){
       par.open("par.txt",ios::app);
       par<<r<<" ";
       par.close();
      }
      else{
       impar.open("impar.txt",ios::app);
       impar<<r<<" ";
       impar.close();
      }
     }
    string  p;
    ifstream  pp("par.txt");
    cout<<"Pares:\n";
      while(pp>>p){
        cout<<p<<" \n";
      }
    ifstream  ii("impar.txt");
    string  i;
      cout<<"impares:\n";
      while(ii>>i){
       cout<<i<<" \n";
      } 
    return 0;
 }
