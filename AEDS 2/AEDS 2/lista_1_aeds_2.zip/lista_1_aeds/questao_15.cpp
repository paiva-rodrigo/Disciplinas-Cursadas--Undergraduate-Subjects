#include<iostream>        
#include <stdlib.h>
#include<fstream>
using namespace std;  
    double media(double a,double b){
     return (a+b)/2;  
    }  
    int main(){
     ifstream ler("questao_15.txt");
     string nome1;
      while(getline(ler,nome1)){
       int ini=0,fim=0;
       fim=nome1.find_first_of(';',ini);
       string nome=nome1.substr(ini,fim-ini);
       
       ini=fim+1;
       fim=nome1.find_first_of(';',ini);
       string nota1=nome1.substr(ini,fim-ini);
       double n1=atof(nota1.c_str());
       
       ini=fim+1;;
       fim=nome1.find_first_of(';',ini);
       string nota2=nome1.substr(ini,fim-ini);
       double n2=atof(nota2.c_str());
       
       cout<<"\nA nota do aluno "<<nome<<" sua media e  "<<(n1+n2)/2;
       if(media(n1,n2)>=6){
        cout<<" e ele passou";
       }
       else{
        cout<<" e ele nao passou";
       } 
      }
     return 0;
    }
