#include<iostream>
 using namespace std;
 float serie(float a){
  if(a==1)
     return 0.5;
  else 
     return (a*a +1)/(a+3)+serie(a-1); 
 }  
 int main(){
  float a;
  cout<<"Digite o valor de um determinado n para calcular o valor da expressao:\n 2/4+5/5+[...]+(n^2+1)/(n+3) :";
  cin>>a;
  cout<<"O valor da expressao acima com  n="<<a<<" e :"<<serie(a);
  
 }
