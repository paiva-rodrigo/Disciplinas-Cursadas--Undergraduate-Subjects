#include<iostream>
#include<fstream>
#include<time.h>
#include <stdlib.h>
using namespace std;
void insercao(int n, long v[]){
int i, j, temp;
	for (j=1; j<n; j++){
	temp = v[j];
		for(i=j-1; i >=0 && v[i]>temp; i--){
		v[i+1] = v[i];
		}
	v[i+1] = temp;
	}
}
void ler (long v[], int t){
    int c=0;
    ifstream fin("numerosaleat.txt");
    int n;
    while (fin>>n){
        v[c++]=n;
    }
    fin.close();
}
int main(){
	int t;
	cout<<"Digite o tamanho do vetor de numeros aleatorios: ";
	cin>>t;
    long vet[t];
    ofstream fout("numerosaleat.txt");
    srand (time(NULL));
		for(int i=0;i<t;i++){
		 if(i==0){
			fout<<rand();
		 }
		 else{
			fout<<endl<<rand();
		 }	
		}
    ler (vet, t);
    insercao(t, vet);
    cout<<"\nO vetor ordenado e: ";
    for (int i=0; i<t; i++){
        cout << " " << vet[i];
    }
}
